# attack_simulation.py - CORRECTED version with proper verification
from collections import Counter
import cipher_logic

def known_plaintext_attack(known_plaintext, ciphertext, key_length=10):
    """Try to recover shift (Caesar) and repeating Vigenere key of length key_length."""
    known_plaintext = "".join(filter(str.isalpha, known_plaintext)).upper()
    ciphertext = "".join(filter(str.isalpha, ciphertext)).upper()
    
    if len(known_plaintext) == 0 or len(ciphertext) == 0:
        return (None, None)
    
    n = min(len(known_plaintext), len(ciphertext))
    
    # First, undo the Caesar shift for each possible shift key
    for s_key_guess in range(26):
        # Remove the Caesar shift to get Vigenere-only ciphertext
        vigenere_only = []
        for c in ciphertext[:n]:
            v_val = ord(c) - ord('A')
            unshifted = (v_val - s_key_guess + 26) % 26
            vigenere_only.append(chr(unshifted + ord('A')))
        vigenere_only = ''.join(vigenere_only)
        
        # Now extract Vigenere shifts from the unshifted text
        vig_shifts = []
        for i in range(n):
            if i < len(known_plaintext):
                v_shift = (ord(vigenere_only[i]) - ord(known_plaintext[i])) % 26
                vig_shifts.append(v_shift)
        
        if len(vig_shifts) < key_length * 2:
            continue
            
        # Look for repeating pattern of key_length
        seg1 = vig_shifts[:key_length]
        seg2 = vig_shifts[key_length:key_length * 2]
        
        if seg1 == seg2:
            # Convert shifts to key string
            key = ''.join(chr(s + ord('A')) for s in seg1)
            
            # Verify the keys actually work
            if verify_recovered_keys(known_plaintext, ciphertext, s_key_guess, key):
                return (s_key_guess, key)
    
    return (None, None)

def verify_recovered_keys(known_plaintext, ciphertext, recovered_shift, recovered_vig_key):
    """Verify that recovered keys actually decrypt the ciphertext back to known plaintext"""
    try:
        # Use the proper decrypt_product function but without transposition
        decrypted = cipher_logic.decrypt_product(
            ciphertext, 
            recovered_vig_key, 
            recovered_shift,
            use_transposition=False,  # KPA assumes no transposition
            autokey=False,
            preserve_nonalpha=False
        )
        
        # Compare with known plaintext (both should be normalized)
        known_normalized = cipher_logic.normalize_text(known_plaintext, preserve_nonalpha=False)
        decrypted_normalized = cipher_logic.normalize_text(decrypted, preserve_nonalpha=False)
        
        # Check if the beginning matches (we might not have the full ciphertext)
        min_len = min(len(known_normalized), len(decrypted_normalized))
        return known_normalized[:min_len] == decrypted_normalized[:min_len]
        
    except Exception as e:
        return False

def frequency_based_shift_guess(ciphertext):
    text = "".join(filter(str.isalpha, ciphertext)).upper()
    if not text:
        return None
    freq = Counter(text)
    most_common = freq.most_common(1)[0][0]
    shift_guess = (ord(most_common) - ord('E')) % 26
    return shift_guess